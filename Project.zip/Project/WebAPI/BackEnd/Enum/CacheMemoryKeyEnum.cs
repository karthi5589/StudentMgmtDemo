﻿namespace StudentWebAPI.Enum
{
    public enum CacheMemoryKeyEnum
    {
        Grades,
        Scores
    }
}