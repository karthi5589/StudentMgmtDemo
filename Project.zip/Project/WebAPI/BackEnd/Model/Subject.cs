﻿namespace StudentWebAPI.Model
{
    public class Subject
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}